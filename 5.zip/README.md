
# 📦 FeedSync — Enterprise Data Sync Platform

FeedSync is een SaaS-ready platform om productdata te importeren, mappen, verrijken en te exporteren naar marketplaces zoals Bol, Amazon en Google Shopping. Ondersteunt tenant-isolatie, logging, templates, API-sync, dashboards en meer.

---

## 🚀 Installatie (handmatig)

```bash
pip install fastapi uvicorn
uvicorn feedsync.main:app --reload
```

Frontend bevindt zich in `dashboard-app/` en kan met bijv. `serve` of Node worden geserveerd.

---

## 🐳 Installatie met Docker Compose

```bash
docker compose up --build
```

Optioneel: pas `.env` aan met je keys.

---

## 🌐 Beschikbare endpoints

- `/feeds/...` voor feedbeheer en exports
- `/marketplaces/...` voor marketplace integraties
- `/orders/...` voor ordersync
- `/themes/colors` voor tenant-kleuren
- `/usage/stats` voor gebruiksoverzicht
- `/tenants/setup` om een tenant te initialiseren
- `/reports/...` voor CSV-log exports

---

## 🧩 Ondersteunde marketplaces

| Kanaal     | Export | Orders | Sync | Mapping |
|------------|--------|--------|------|---------|
| Bol.com    | ✅     | ✅     | ✅   | ✅      |
| Amazon     | ✅     | ✅     | ✅   | ✅      |
| Google Shopping | ✅ | -      | -    | ✅      |
| Lightspeed | 🔄 Import | - | - | via mapping |

---

## 📝 Notities

- Frontend = React (JSX-bestand in dashboard-app)
- Backend = FastAPI (Python 3.10+)
- Postgres optioneel (voor persistente opslag)

---

## 💡 Quickstart script

```bash
./install.sh
```

Vraagt om Docker-optie + installeert dependencies automatisch.

---

## 📄 Licentie

MIT – vrije aanpassing, commercieel gebruik toegestaan.

---


#!/bin/bash

echo "🚀 FeedSync installatie start..."

# 1. Python omgeving opzetten
echo "📦 Python requirements installeren..."
pip install --upgrade pip
pip install fastapi uvicorn

# 2. Optioneel: Docker Compose opstarten
read -p "❓ Wil je Docker Compose starten? (y/n): " dockerchoice
if [[ "$dockerchoice" == "y" ]]; then
  echo "🐳 Docker Compose wordt gestart..."
  docker compose up --build
else
  echo "ℹ️ Je kunt het handmatig starten met: docker compose up --build"
fi

# 3. Handmatige run info
echo "✅ Installatie gereed. Start backend met:"
echo "    uvicorn feedsync.main:app --reload"

echo "💡 Vergeet niet om een .env bestand aan te maken indien nodig."

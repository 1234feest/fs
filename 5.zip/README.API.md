# API-documentatie
Zie /docs (FastAPI auto-generated).
Auth vereist via API_KEY header.

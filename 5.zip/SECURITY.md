# FeedSync Responsible Disclosure
Mail eventuele kwetsbaarheden naar security@feedsync.local.
Wij reageren binnen 5 werkdagen.

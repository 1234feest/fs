# 🚀 FeedSync v2.1 Release Notes
Nieuwe roadmapbatch 1321–1340 voltooid. Bevat release metadata, metrics endpoint, SHA-verificatie en manifest.json.

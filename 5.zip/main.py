import os
import logging
import base64
from typing import List
from fastapi import FastAPI, HTTPException, Path, Query, Depends, status
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
import requests
from sqlalchemy import create_engine, Column, String, Integer, DateTime, text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, Session
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
from apscheduler.schedulers.background import BackgroundScheduler
import atexit

# --- AUTH SETTINGS ---
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "fallback-voor-dev-niet-in-productie")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# --- DATABASE ---
load_dotenv(dotenv_path=".env.production")
logging.basicConfig(level=logging.INFO)

app = FastAPI(title="FeedSync API", version="1.0.0")
scheduler = BackgroundScheduler()

# === CORS MIDDLEWARE ===
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://feedsync-frontend.fly.dev",
        "http://localhost:5173",  # optioneel: voor lokaal testen
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./test.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# MODELS

class Tenant(Base):
    __tablename__ = "tenants"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    users = relationship("User", back_populates="tenant")

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    tenant_id = Column(Integer, ForeignKey("tenants.id"))
    role = Column(String, default="user")
    is_active = Column(Integer, default=1)
    tenant = relationship("Tenant", back_populates="users")

class Order(Base):
    __tablename__ = "bol_orders"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    order_id = Column(String, unique=True, index=True)
    order_item_id = Column(String)
    ean = Column(String)
    customer = Column(String, default="bol.com")
    status = Column(String)
    placed_at = Column(DateTime)
    tenant_id = Column(Integer, ForeignKey("tenants.id"), nullable=True)

class Feed(Base):
    __tablename__ = "feeds"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    status = Column(String, default="Actief")
    last_synced = Column(String, default="")

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ===================
# AUTH ENDPOINTS
# ===================

class RegisterRequest(BaseModel):
    email: str
    password: str
    tenant_name: str

@app.post("/register")
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    email = req.email
    password = req.password
    tenant_name = req.tenant_name
    tenant = db.query(Tenant).filter_by(name=tenant_name).first()
    if not tenant:
        tenant = Tenant(name=tenant_name)
        db.add(tenant)
        db.commit()
        db.refresh(tenant)
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(status_code=400, detail="Gebruiker bestaat al")
    # Check hoeveel users deze tenant heeft
    tenant_users = db.query(User).filter_by(tenant_id=tenant.id).count()
    role = "admin" if tenant_users == 0 else "user"
    user = User(
        email=email,
        hashed_password=get_password_hash(password),
        tenant_id=tenant.id,
        role=role
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"msg": "Geregistreerd, nu inloggen via /token", "role": role}

@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Onjuiste inloggegevens")
    access_token = create_access_token(data={"sub": str(user.id), "tenant": user.tenant_id, "role": user.role})
    return {"access_token": access_token, "token_type": "bearer"}

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=401,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload.get("sub"))
        user = db.query(User).filter(User.id == user_id).first()
        if not user or not user.is_active:
            raise credentials_exception
        return user
    except JWTError:
        raise credentials_exception

@app.get("/me")
def read_me(current_user: User = Depends(get_current_user)):
    return {
        "id": current_user.id,
        "email": current_user.email,
        "tenant": current_user.tenant_id,
        "role": current_user.role
    }

def require_admin(current_user: User = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Alleen admin users toegestaan")
    return current_user

# ===================
# MULTI-TENANT ORDER ENDPOINTS
# ===================

class OrderUpdate(BaseModel):
    status: str

@app.get("/orders")
def get_orders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    status: str = Query(None, description="Filter op status, bv. OPEN"),
    customer: str = Query(None, description="Filter op klant, bv. 'bol.com' of 'lightspeed'"),
    limit: int = Query(100, ge=1, le=1000, description="Max aantal resultaten"),
    offset: int = Query(0, ge=0, description="Aantal te skippen resultaten")
):
    query = db.query(Order).filter(Order.tenant_id == current_user.tenant_id)
    if status:
        query = query.filter(Order.status == status)
    if customer:
        query = query.filter(Order.customer == customer)
    orders = query.offset(offset).limit(limit).all()
    result = []
    for o in orders:
        result.append({
            "id": o.id,
            "order_id": o.order_id,
            "order_item_id": o.order_item_id,
            "ean": o.ean,
            "customer": o.customer,
            "status": o.status,
            "placed_at": o.placed_at.isoformat() if o.placed_at else None
        })
    return JSONResponse(content=result)

@app.delete("/orders/{order_id}")
def delete_order(
    order_id: str = Path(..., description="Order ID"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    order = db.query(Order).filter(Order.order_id == order_id, Order.tenant_id == current_user.tenant_id).first()
    if not order:
        return {"status": "error", "detail": "Order niet gevonden"}
    db.delete(order)
    db.commit()
    return {"status": "ok", "deleted_order_id": order_id}

@app.put("/orders/{order_id}")
def update_order(
    order_id: str,
    update: OrderUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    order = db.query(Order).filter(Order.order_id == order_id, Order.tenant_id == current_user.tenant_id).first()
    if not order:
        return {"status": "error", "detail": "Order niet gevonden"}
    order.status = update.status
    db.commit()
    return {"status": "ok", "order_id": order_id, "new_status": update.status}

# ===================
# FEEDS ENDPOINTS
# ===================

class FeedBase(BaseModel):
    name: str
    status: str
    last_synced: str

class FeedOut(FeedBase):
    id: int

    class Config:
        orm_mode = True

@app.get("/feeds", response_model=List[FeedOut])
def get_feeds(db: Session = Depends(get_db)):
    return db.query(Feed).all()

@app.post("/feeds", response_model=FeedOut)
def create_feed(feed: FeedBase, db: Session = Depends(get_db)):
    db_feed = Feed(
        name=feed.name,
        status=feed.status,
        last_synced=feed.last_synced
    )
    db.add(db_feed)
    db.commit()
    db.refresh(db_feed)
    return db_feed

# ===================
# EXTERNAL SYNC (BOL, LIGHTSPEED)
# ===================

def get_bol_access_token():
    url = "https://login.bol.com/token?grant_type=client_credentials"
    auth = (os.getenv("BOL_CLIENT_ID"), os.getenv("BOL_CLIENT_SECRET"))
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = requests.post(url, auth=auth, headers=headers)
    if response.status_code != 200:
        logging.error("Bol auth failed: %s", response.text)
        raise HTTPException(status_code=500, detail="Bol auth failed")
    return response.json()["access_token"]

@app.get("/bol/orders/sync")
def sync_bol_orders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    logging.info("Start sync Bol orders")
    token = get_bol_access_token()
    headers = {
        "Accept": "application/vnd.retailer.v9+json",
        "Authorization": f"Bearer {token}"
    }
    response = requests.get("https://api.bol.com/retailer/orders", headers=headers)
    if response.status_code != 200:
        logging.error("Failed to fetch orders: %s", response.text)
        raise HTTPException(status_code=500, detail="Failed to fetch orders")

    inserted = 0
    for order in response.json().get("orders", []):
        for item in order.get("orderItems", []):
            if not db.query(Order).filter_by(order_item_id=item["orderItemId"], tenant_id=current_user.tenant_id).first():
                db_order = Order(
                    order_id=order["orderId"],
                    order_item_id=item["orderItemId"],
                    ean=item["ean"],
                    status=item["fulfilmentStatus"],
                    placed_at=datetime.fromisoformat(order["orderPlacedDateTime"]),
                    tenant_id=current_user.tenant_id
                )
                db.add(db_order)
                inserted += 1
    db.commit()
    logging.info(f"Bol orders synced: {inserted}")
    return {"synced": inserted}

def get_lightspeed_headers():
    client_id = os.getenv("LIGHTSPEED_CLIENT_ID")
    client_secret = os.getenv("LIGHTSPEED_CLIENT_SECRET")
    basic_token = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
    return {
        "Authorization": f"Basic {basic_token}",
        "Accept": "application/json"
    }

@app.get("/lightspeed/orders/sync")
def sync_lightspeed_orders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    api_url = os.getenv("LIGHTSPEED_API_URL", "").rstrip("/")
    headers = get_lightspeed_headers()
    url = f"{api_url}/orders.json"
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        logging.error("Failed to fetch Lightspeed orders: %s", response.text)
        raise HTTPException(status_code=500, detail="Failed to fetch Lightspeed orders")

    inserted = 0
    for order in response.json().get("orders", []):
        for item in order.get("orderItems", []):
            if not db.query(Order).filter_by(order_item_id=str(item["id"]), tenant_id=current_user.tenant_id).first():
                db_order = Order(
                    order_id=str(order["id"]),
                    order_item_id=str(item["id"]),
                    ean=item.get("ean", ""),
                    status=item.get("status", ""),
                    customer="lightspeed",
                    placed_at=datetime.fromisoformat(order["createdAt"]),
                    tenant_id=current_user.tenant_id
                )
                db.add(db_order)
                inserted += 1
    db.commit()
    logging.info(f"Lightspeed orders synced: {inserted}")
    return {"synced": inserted}

@app.get("/healthz")
def healthz():
    try:
        db = SessionLocal()
        db.execute(text("SELECT 1"))
        db.close()
        return {"status": "ok"}
    except Exception as e:
        logging.error("Healthcheck failed: %s", str(e))
        return {"status": "error", "details": str(e)}

# ===================
# ADMIN
# ===================

@app.get("/admin/users")
def list_users(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    users = db.query(User).filter_by(tenant_id=current_user.tenant_id).all()
    return [
        {
            "id": u.id,
            "email": u.email,
            "role": u.role
        }
        for u in users
    ]

# ===================
# SCHEDULER
# ===================

def periodic_sync(endpoint):
    try:
        r = requests.get(f"http://localhost:8000{endpoint}")
        logging.info(f"[Scheduler] {endpoint} -> {r.status_code} {r.text}")
    except Exception as e:
        logging.error(f"[Scheduler] {endpoint} sync failed: {e}")

def start_background_jobs():
    try:
        scheduler.add_job(lambda: periodic_sync("/bol/orders/sync"), 'interval', minutes=10)
        scheduler.add_job(lambda: periodic_sync("/lightspeed/orders/sync"), 'interval', minutes=15)
        scheduler.start()
        logging.info("BackgroundScheduler started (Bol: 10min, Lightspeed: 15min)")
    except Exception as e:
        logging.error(f"Failed to start scheduler: {e}")

@app.on_event("startup")
def startup_event():
    start_background_jobs()

atexit.register(lambda: scheduler.shutdown(wait=False))

# Rollen en Rechten
| Rol     | Mag mappings bewerken | Mag exports starten |
|---------|------------------------|----------------------|
| admin   | ✅                     | ✅                   |
| editor  | ✅                     | ✅                   |
| viewer  | ❌                     | ✅ (alleen lezen)     |

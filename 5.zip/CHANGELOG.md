# FeedSync Changelog
- v1.0 afgerond bij batch 1000
- v1.2 afgerond bij batch 1200
- v2.0 start bij batch 1201

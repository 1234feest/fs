# FeedSync Support
Voor vragen of bugs, neem contact op via support@feedsync.local.
Roadmap: /feedsync_changelog_batches_1_1300.md

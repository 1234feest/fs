# Multi-Tenant
Elke tenant heeft:
- eigen mappingregels
- eigen API key
- gescheiden UI-thema

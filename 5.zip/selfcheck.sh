#!/bin/bash
echo "✅ Python:" $(python3 --version)
echo "✅ Pip:" $(pip --version)
echo "✅ Uvicorn versie:" $(uvicorn --version || echo 'niet geïnstalleerd')

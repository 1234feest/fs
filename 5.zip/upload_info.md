Plaats deze ZIP op artifact.feedsync.local of upload naar interne package manager.

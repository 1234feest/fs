#!/bin/bash
echo "FeedSync CLI"
echo "1. Run export"
echo "2. Run test"

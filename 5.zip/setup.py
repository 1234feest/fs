from setuptools import setup
setup(name='feedsync', version='0.1')

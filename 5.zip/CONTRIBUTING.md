# Bijdragen aan FeedSync
1. Fork dit project
2. Maak je feature branch
3. Pull request met uitleg

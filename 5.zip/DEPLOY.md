# Deployment Instructies

## Vereisten
- Docker & Docker Compose
- .env bestand met configuratie (zie .env.example)

## Starten
1. `docker-compose build`
2. `docker-compose up`
3. `docker exec -it <backend_container> bash`
4. `sh scripts/migrate.sh`
5. `python scripts/seed.py`
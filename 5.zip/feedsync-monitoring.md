# Monitoring
- `/health` → API status
- `/metrics` → integratie mogelijk met Prometheus

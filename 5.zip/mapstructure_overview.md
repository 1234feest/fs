# FeedSync Mappenstructuur
- feedsync/: backend API
- dashboard-app/: frontend UI
- docs/: API en installatie
- .github/: CI workflows
- metadata/: versie info, manifest, metrics

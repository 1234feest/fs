# Centrale loggingconfig (ELK/JSON)

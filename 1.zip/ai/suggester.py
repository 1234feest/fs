
from core.feedback_log import get_feedback
from collections import Counter

def suggest_rules(tenant: str, channel: str):
    feedback = get_feedback(tenant, channel)
    if not feedback:
        return ["price_rounder", "title_cleaner"]  # defaults

    all_successful = [tuple(f["plugins"]) for f in feedback if f["success"]]
    if not all_successful:
        return ["base_fallback"]

    most_common = Counter(all_successful).most_common(1)[0][0]
    return list(most_common)

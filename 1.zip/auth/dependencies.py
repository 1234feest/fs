from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from core.models import User
from core.database import get_db

def get_current_user():
    return User(id=1, email="admin@example.com", role_id=1)

def get_current_active_admin(current_user: User = Depends(get_current_user)):
    if current_user.role_id != 1:
        raise HTTPException(status_code=403, detail="Admin privileges required.")
    return current_user
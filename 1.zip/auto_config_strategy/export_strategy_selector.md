# Exportstrategie Selector
Kies tussen:
- Push → bij trigger direct versturen
- Sync → tijdsinterval
- Fetch → extern ophalen

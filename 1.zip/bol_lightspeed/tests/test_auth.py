
def test_dummy_auth():
    assert True


def test_dummy_core():
    assert True

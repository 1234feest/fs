
from celery import Celery
import logging

logger = logging.getLogger(__name__)
app = Celery("worker")

@app.task(bind=True)
def sync_products(self):
    logger.info("Start: Sync products")
    try:
        # Simulated task logic
        logger.info("Success: Sync complete")
    except Exception as e:
        logger.error(f"Error during sync: {str(e)}")
        raise e

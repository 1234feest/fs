
# Architectuuroverzicht

## Technologieën
- FastAPI, SQLAlchemy, Alembic, Celery, Redis
- PostgreSQL, Docker, JWT-authenticatie

## Structuur
- core/: modellen, database
- auth/: authenticatie
- dashboard/: API-routes
- feeds/: exportsystemen
- rules_engine/: prijssuggesties & voorraadregels

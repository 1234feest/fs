
# Gebruikershandleiding

## Aanmelden en Inloggen
1. Ga naar /login
2. Voer e-mail en wachtwoord in

## Koppelingen instellen
- Voer API-keys in bij instellingen
- Selecteer kanalen (Bol, Lightspeed)

## Synchronisatie
- Handmatig: via dashboard 'Sync Nu'
- Automatisch: draait via Celery

## Abonnement beheren
- Kies een plan bij 'Abonnementen'
- Mock: geen echte betaling vereist

## Foutmeldingen oplossen
- Check 'Logs' pagina
- Neem contact op via support@example.com

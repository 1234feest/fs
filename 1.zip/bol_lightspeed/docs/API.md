
# API Documentatie

## Voorbeeldaanroepen

### Inloggen
```http
POST /auth/login
Content-Type: application/json
{
  "email": "admin@example.com",
  "password": "yourpassword"
}
```

### Voorraad synchroniseren
```http
POST /sync/trigger
Authorization: Bearer <JWT>
```


# RELEASE NOTES – v1.0.0

Deze release bevat:
- Functionele koppeling met Bol.com & Lightspeed
- Mock abonnementensysteem (Stripe/Mollie)
- Volledige Docker deployment
- API-documentatie en gebruikershandleiding

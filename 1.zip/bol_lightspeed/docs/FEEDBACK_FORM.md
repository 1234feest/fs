
# Gebruikersfeedbackformulier

Vul dit formulier in na het testen van de SaaS koppeling:

## Algemene indruk
- Wat vond je van de snelheid en betrouwbaarheid?

## Gebruikerservaring
- Was het dashboard duidelijk en makkelijk te gebruiken?

## Bugs
- Heb je fouten of crashes ervaren? Zo ja, waar?

## Gewenste functies
- Wat mis je nog in deze versie?

## Overig
- Aanvullende opmerkingen of vragen?

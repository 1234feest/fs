
# CHANGELOG

## v1.0.0 (2025-06-29)
- Eerste volledige versie
- Bol + Lightspeed integratie
- Multi-tenant & JWT-auth
- Logging, Celery, Docker & API

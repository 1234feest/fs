
# Feedback Log

## Pilot 1 – 2025-06-29
- ✅ Dashboard werkte intuïtief
- 🛠️ Wens: sortering op logs-pagina
- ❗ Bug: foutmelding bij handmatige sync zonder gekoppelde feed

## Pilot 2 – 2025-06-30
- ✅ AI prijssuggesties goed zichtbaar
- ❗ Bug: voorraadalerts laden traag bij grote feed

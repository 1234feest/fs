
# Installatie-instructies

## Vereisten
- Docker, Docker Compose
- Python 3.11+ (optioneel voor lokaal draaien)

## Lokaal draaien
```bash
cp .env.example .env
docker-compose up --build
```

## Alembic migreren
```bash
./scripts/migrate.sh
```

## Seed data (optioneel)
```bash
python ./scripts/seed.py
```

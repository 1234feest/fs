
# BUGLOG

## 2025-06-29
- Toegevoegd: Celery logging verbeterd
- Toegevoegd: /status healthcheck endpoint
- Testbestanden toegevoegd voor auth en core modules

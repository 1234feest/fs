
from fastapi import APIRouter, Request

router = APIRouter()

feedback_log = []

@router.post("/feedback")
async def submit_feedback(request: Request):
    data = await request.json()
    feedback_log.append(data)
    return {"message": "Feedback ontvangen", "data": data}

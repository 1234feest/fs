
from fastapi import APIRouter
import time

router = APIRouter()

start_time = time.time()

@router.get("/status")
def health_check():
    uptime = int(time.time() - start_time)
    return {"status": "ok", "uptime_seconds": uptime}


from fastapi import APIRouter

router = APIRouter()

@router.get("/monitoring")
def monitoring_data():
    return {
        "uptime": "ok",
        "sync_jobs_running": False,
        "db_status": "connected"
    }


# Voorbeeld seed-script
from bol_lightspeed.core.database import SessionLocal
from bol_lightspeed.core.models import User

db = SessionLocal()
user = User(email="admin@example.com", hashed_password="hashed", role="admin")
db.add(user)
db.commit()
db.close()

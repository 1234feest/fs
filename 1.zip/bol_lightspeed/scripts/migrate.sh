
#!/bin/bash
alembic upgrade head

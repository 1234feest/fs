# Autoscaling Hints
Detecteert piekverkeer per kanaal en adviseert throttle/parallelisatie.

# Mappingregel Aging Report
- R002 'voorraadfilter' → 144 dagen ongewijzigd
- R005 'title prefix' → 7 dagen geleden aangepast

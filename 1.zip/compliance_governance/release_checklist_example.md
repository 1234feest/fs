# Release Checklist
- ✅ Mappingregels gevalideerd
- ✅ Exports gesimuleerd
- ✅ Tokenrechten gecontroleerd

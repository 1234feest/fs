# Channel QA Dashboard
Toont per kanaal:
- Aantal exports
- Fouten per regel
- Validatiescore over tijd

# Rule Impact Calculator
Als regel X wordt aangepast, hoeveel records en welke kanalen zijn beïnvloed?

# Copilot Personality Modes
- Minimal: genereer alleen verplichte regels
- Commercial: focus op verkoopoptimalisatie
- Strict: valideer alles, hoge drempel

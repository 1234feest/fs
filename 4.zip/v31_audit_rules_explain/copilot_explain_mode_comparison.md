# Copilot Explain Mode
- Short: "filter op voorraad > 0 voor Bol"
- Full: "deze regel zorgt dat alleen producten met voorraad > 0 zichtbaar zijn in Bol feed, om afkeuring te voorkomen"

# Blueprint Rule Scan Result
- Regel 3 ontbreekt required GTIN check
- Regel 6 overschrijft logica uit regel 4
- Exportstructuur valide

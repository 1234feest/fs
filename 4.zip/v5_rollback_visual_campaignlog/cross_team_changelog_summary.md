# Cross-Team Changelog
- Team Content wijzigde 'title_enrichment' op 2024-06-25
- Team Performance paste 'pricing_adjustment' aan op 2024-06-26

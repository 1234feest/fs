# Changelog-narratief – Bol zomer
- Titelregel herschreven voor optimalisatie
- GTIN-regel toegevoegd wegens afkeur
- Pricing fallback verwijderd → rollback na approvaldrop van 18%

# Fallback Flow Plan
- Bij fout op kanaal 'Meta', activeer Google Shopping flow met fallbackregel voor GTIN

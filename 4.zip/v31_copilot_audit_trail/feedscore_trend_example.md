# Feedscore Trend - Bol zomerfeed
- Maart: 72
- April: 78
- Mei: 81
- Juni: 86

# Branch Preview: 'bol-sale-v2'
- Regel 'prijsfilter' aangepast: <120 → <100
- Titelverrijkingregel toegevoegd
- Exportstructuur gewijzigd naar 'offers_only.xml'

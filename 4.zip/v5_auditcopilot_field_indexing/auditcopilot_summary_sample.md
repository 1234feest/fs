# AuditCopilot Samenvatting
- In juni werden 12 regels gewijzigd in 4 feeds
- Belangrijkste aanpassing: GTIN-verplichting voor Bol → goedkeuringspercentage +9%
- Titelregels herschreven voor Meta → klikratio +5%

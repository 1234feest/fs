# Mappingrule API
- GET /api/v1/mappingrules/{id}
- PUT /api/v1/mappingrules/{id}
- GET /api/v1/mappingrules/{id}/diff?compareTo={otherId}

# Copilot Diff Summary
- Titelregel is herschreven voor duidelijkheid
- Prijsregel is aangepast van 'price > 0' naar 'price >= 1'
- Exportstructuur is gelijk gebleven

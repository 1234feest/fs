# Regel Evolution History: 'kortingregel'
- v1: als prijs < 100 → label = SALE
- v2: als prijs < 100 én voorraad > 0 → label = SALE
- v3: als prijs < 90 én voorraad > 1 → label = SALE

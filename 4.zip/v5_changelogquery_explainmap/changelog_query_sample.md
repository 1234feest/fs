# Changelog Query Result
Filters: reviewer = qa_team, channel = Bol, effect = approval rate ↑
- 2024-06-20: Regel 'stock > 0' live gezet, +5% goedkeuring
- 2024-06-22: Titelregel ingekort, +8% CTR

# Copilot Chain Voorstel
1. Filter op voorraad > 0
2. Voeg label toe: 'SALE'
3. Verrijk titel met merk + model

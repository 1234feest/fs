# Copilot Context Inject Sample
Gebruiker werkte eerder aan Bol feed → prioriteer regels rond voorraad en prijsvalidatie

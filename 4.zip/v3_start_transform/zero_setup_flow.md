# Zero-Setup Starter
- Stap 1: upload importbestand
- Stap 2: AI detecteert bronvelden
- Stap 3: Mapping wordt voorgesteld
- Stap 4: Preview → Activeer

# Runtime Validation Log
- Rule v2 rejected: logic conflicts with stock filter in rule r212
- Rule v3 accepted: all requirements met

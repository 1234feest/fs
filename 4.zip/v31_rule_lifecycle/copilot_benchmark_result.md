# Copilot Benchmark Result
- editor01 → 72% acceptatie, meeste correcties bij prijsregels
- editor02 → 84% acceptatie, topprestatie bij title-suggesties

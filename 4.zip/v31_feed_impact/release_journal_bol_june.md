# Releasejournaal - Bol.com (juni)
- Nieuwe prijsfilterregel live: 2024-06-10
- Titelverrijking geactiveerd: 2024-06-14
- Exportstructuur gewijzigd naar 'catalog_v4.xml': 2024-06-22

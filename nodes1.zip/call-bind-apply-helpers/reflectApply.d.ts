declare const reflectApply: false | typeof Reflect.apply;

export = reflectApply;

require("../dist/register").registerJSX();

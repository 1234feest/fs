export declare function shallow<T>(valueA: T, valueB: T): boolean;

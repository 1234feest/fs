export { shallow } from 'zustand/vanilla/shallow';
export { useShallow } from 'zustand/react/shallow';

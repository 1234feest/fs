export declare function useShallow<S, U>(selector: (state: S) => U): (state: S) => U;

from pydantic import BaseModel

class UserCreate(BaseModel):
    email: str
    hashed_password: str
    role_id: int

class UserOut(BaseModel):
    id: int
    email: str
    role_id: int

    class Config:
        orm_mode = True
def test_order_import_stub():
    result = {"imported": True}
    assert result["imported"]
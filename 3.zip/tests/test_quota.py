from core.usage import increment_usage, get_usage

def test_usage_increment():
    user_id = 123
    increment_usage(user_id, "syncs")
    assert get_usage(user_id)["syncs"] == 1
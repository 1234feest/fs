def test_dummy_user_creation():
    assert True  # Voorbeeldtest — breid later uit met client POST /users

from fastapi.testclient import TestClient
from feedsync.main import app

client = TestClient(app)

def test_login_success():
    response = client.post("/auth/login", json={
        "email": "admin@demo.com",
        "password": "adminpass",
        "tenant": "tenant-a"
    })
    assert response.status_code == 200
    assert "token" in response.json()

def test_login_fail():
    response = client.post("/auth/login", json={
        "email": "wrong@demo.com",
        "password": "nopass",
        "tenant": "tenant-a"
    })
    assert response.status_code == 401

def test_auth_stub():
    user = {"role_id": 1}
    assert user["role_id"] == 1
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_admin_access_denied(monkeypatch):
    class DummyUser:
        id = 1
        role_id = 2  # geen admin
    monkeypatch.setattr("auth.dependencies.get_current_user", lambda: DummyUser())
    response = client.get("/admin/dashboard")
    assert response.status_code == 403

def test_admin_access_allowed(monkeypatch):
    class DummyAdmin:
        id = 1
        role_id = 1  # admin
    monkeypatch.setattr("auth.dependencies.get_current_user", lambda: DummyAdmin())
    response = client.get("/admin/dashboard")
    assert response.status_code == 200
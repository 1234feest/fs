from core.usage import get_usage
from core.sync import manual_sync

def test_manual_sync():
    user_id = 999
    manual_sync(user_id)
    assert get_usage(user_id)["syncs"] == 1
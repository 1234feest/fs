
from fastapi.testclient import TestClient
from feedsync.main import app

client = TestClient(app)

def test_feed_export():
    feed = {
        "name": "bol-feed",
        "channel": "bol",
        "rules": [
            { "field": "voorraad", "operator": ">", "value": "0" }
        ]
    }
    client.post("/feeds", headers={"X-Tenant-ID": "tenant-a"}, json=feed)
    r = client.get("/feeds/export", headers={"X-Tenant-ID": "tenant-a"}, params={"name": "bol-feed"})
    assert r.status_code == 200
    assert "sku" in r.text

def test_logging():
    client.post("/logs", headers={"X-Tenant-ID": "tenant-a"}, params={"feed": "bol-feed", "message": "test log"})
    r = client.get("/logs", headers={"X-Tenant-ID": "tenant-a"}, params={"feed": "bol-feed"})
    assert r.status_code == 200
    assert any("test log" in e["message"] for e in r.json())

def test_alert_send():
    payload = {
        "to": "test@domain.com",
        "subject": "Alert!",
        "body": "Something happened."
    }
    r = client.post("/alerts/send", headers={"X-Tenant-ID": "tenant-a"}, json=payload)
    assert r.status_code == 200
    assert r.json()["status"] == "sent"

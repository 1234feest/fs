import pytest
from fastapi.testclient import TestClient
from feedsync.main import app

client = TestClient(app)

def test_empty_inventory_sync():
    response = client.post("/sync/inventory", json={}, headers={"X-Tenant-ID": "tenant-a"})
    assert response.status_code in (400, 422)

def test_missing_tenant_header():
    response = client.get("/tenant/quota")
    assert response.status_code in (400, 422, 401)

def test_invalid_token_access():
    headers = {
        "Authorization": "Bearer FAKE-TOKEN",
        "X-Tenant-ID": "tenant-a"
    }
    response = client.get("/tenant/config", headers=headers)
    assert response.status_code == 401

def test_quota_exceeded_sim():
    # Simulatie door veelvuldig opvragen zonder quota check reset
    for _ in range(100):
        client.get("/tenant/quota", headers={"X-Tenant-ID": "tenant-a"})
    response = client.get("/tenant/quota", headers={"X-Tenant-ID": "tenant-a"})
    assert response.status_code == 200


from fastapi.testclient import TestClient
from feedsync.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200 or response.status_code == 404  # placeholder

import pytest

def test_error_format():
    err = {"code": "X", "message": "Test"}
    assert "code" in err and "message" in err
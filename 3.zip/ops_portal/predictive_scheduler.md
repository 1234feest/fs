# Predictive Delivery Scheduler
AI bepaalt exporttijd o.b.v. historische load en kanaalbeschikbaarheid.

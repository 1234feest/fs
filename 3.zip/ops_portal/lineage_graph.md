# Export Lineage Graph
Record X → Mappingregel 12 → Feed BOL → Delivery → Status: success

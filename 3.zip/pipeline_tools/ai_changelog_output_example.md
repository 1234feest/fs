# AI Changelog Generator
- Titelregel toegevoegd
- Prijsregel aangepast van >0 naar >=0
- Exportstructuur gewijzigd naar XML

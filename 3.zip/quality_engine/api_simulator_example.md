# API Simulator
Stuur POST naar /simulate with feed + mapping config.
Ontvang: mapped result preview.

# Semantic Mapping Search Voorbeelden
- "regel die prijs filtert"
- "feed met GTIN en voorraadregels"
- "alles voor Bol met korting in titel"

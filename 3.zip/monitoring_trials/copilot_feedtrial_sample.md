# Copilot Feedtrial (voor Bol)
Testresultaat:
- Subset: 125 producten
- Verwerkt: 118
- Fouten: 7 (prijs negatief, lege titel)


def push_to_amazon(product: dict):
    # Mock functie voor Amazon-integratie
    print(f"[Amazon] Upload product: {product['sku']}")
    return {"status": "success", "channel": "amazon"}

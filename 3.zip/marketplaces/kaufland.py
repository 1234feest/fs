
def push_to_kaufland(product: dict):
    # Mock functie voor Kaufland-integratie
    print(f"[Kaufland] Sync product: {product['sku']}")
    return {"status": "success", "channel": "kaufland"}

# FeedSync Installatie

## Vereisten
- Docker + Docker Compose
- Python 3.10+ (voor lokaal gebruik)
- Redis (voor Celery)

## Setup

1. Vul `.env` in op basis van `.env.example`
2. Start met Docker:

```bash
docker-compose up --build
```

3. Bezoek:
- API: http://localhost:8000/docs
- Dashboard: http://localhost:8000/dashboard

## Extra
- Celery worker start je met: `docker-compose run celery`
- Feedback zichtbaar via `/feedback/all`


## CLI Gebruik

Start sync vanaf command line:

```bash
feedsync-cli sync --sku ABC123 --qty 10
```

Bekijk tenant quota:

```bash
feedsync-cli quota --tenant tenant-a
```

## API Voorbeelden

Voorraad sync:

```http
POST /sync/inventory
Headers:
  Content-Type: application/json
  X-Tenant-ID: tenant-a

Body:
{
  "sku": "ABC123",
  "qty": 5
}
```

Feedback insturen:

```http
POST /feedback
Headers:
  X-Tenant-ID: tenant-a
Params:
  message=super tool
```

Tenant-config wijzigen:

```http
POST /tenant/update
Headers:
  X-Tenant-ID: tenant-a

Body:
{
  "theme": "dark",
  "features": {"allow_webhooks": false}
}
```

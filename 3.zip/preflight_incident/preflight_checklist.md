# Preflight Checklist
- ✅ Titelveld aanwezig
- ✅ Prijs ingevuld
- ✅ Voorraadregel actief

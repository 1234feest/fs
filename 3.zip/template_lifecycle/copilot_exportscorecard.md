# Copilot Exportscorecard
Toont exportkwaliteit op basis van gegenereerde mappings.

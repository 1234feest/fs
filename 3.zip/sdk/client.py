
import requests

class FeedSyncClient:
    def __init__(self, base_url: str, api_key: str = None):
        self.base_url = base_url.rstrip("/")
        self.headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}

    def trigger_sync(self):
        return requests.post(f"{self.base_url}/sync/trigger", headers=self.headers).json()

    def get_status(self):
        return requests.get(f"{self.base_url}/status", headers=self.headers).json()

    def suggest_rules(self, tenant, channel):
        return requests.get(
            f"{self.base_url}/ai/suggest-rules",
            headers=self.headers,
            params={"tenant": tenant, "channel": channel}
        ).json()

    def export_feed(self, tenant, config, rules):
        return requests.post(
            f"{self.base_url}/gitops/export",
            json={"tenant": tenant, "config": config, "rules": rules},
            headers=self.headers
        ).json()

#!/bin/bash
echo "Pilot omgeving inrichten..."
docker-compose up -d
sleep 3
docker exec -i $(docker ps -qf name=backend) sh -c "python scripts/seed.py"
#!/bin/bash
echo "Restore uitvoeren..."
cat backup.sql | docker exec -i $(docker ps -qf name=db) psql -U feedsync feedsync
echo "Restore voltooid"
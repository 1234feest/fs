from core.models import User
from core.database import SessionLocal

db = SessionLocal()
admin = User(email="admin@example.com", hashed_password="admin", role_id=1)
db.add(admin)
db.commit()
db.close()
print("Admin user seeded.")
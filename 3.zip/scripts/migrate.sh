#!/bin/bash
echo "Applying database migrations..."
alembic upgrade head
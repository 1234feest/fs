#!/bin/bash
echo "Backup maken..."
docker exec -t $(docker ps -qf name=db) pg_dump -U feedsync feedsync > backup.sql
echo "Backup opgeslagen als backup.sql"
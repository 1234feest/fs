# Field Learning Engine
Gebruikt vorige mappings om nieuwe CSV's automatisch te koppelen.


import importlib
from rules_engine.plugins.base import RulePlugin

def load_plugins(plugin_names):
    instances = []
    for name in plugin_names:
        try:
            module = importlib.import_module(f"rules_engine.plugins.{name}")
            plugin_class = getattr(module, name)
            instance = plugin_class()
            if isinstance(instance, RulePlugin):
                instances.append(instance)
        except Exception as e:
            print(f"Plugin {name} kon niet geladen worden: {str(e)}")
    return instances

def apply_chain(product, plugin_chain):
    result = product.copy()
    for plugin in plugin_chain:
        result = plugin.apply(result)
    return result

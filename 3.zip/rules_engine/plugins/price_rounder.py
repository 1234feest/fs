
from .base import RulePlugin

class PriceRounder(RulePlugin):
    name = "PriceRounder"

    def apply(self, product: dict) -> dict:
        if "price" in product:
            product["price"] = round(float(product["price"]))
        return product

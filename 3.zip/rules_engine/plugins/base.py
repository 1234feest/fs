
class RulePlugin:
    name = "BasePlugin"

    def apply(self, product: dict) -> dict:
        raise NotImplementedError("Moet worden geïmplementeerd door subclass.")

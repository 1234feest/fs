def price_above(product, minimum):
    return product.get("price", 0) > minimum

def stock_below(product, maximum):
    return product.get("stock", 9999) < maximum
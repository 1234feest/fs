from rules_engine.conditions import price_above, stock_below

def evaluate(product, rules: list):
    results = []
    for rule in rules:
        if rule["type"] == "price_above":
            results.append(price_above(product, rule["value"]))
        elif rule["type"] == "stock_below":
            results.append(stock_below(product, rule["value"]))
    return all(results)
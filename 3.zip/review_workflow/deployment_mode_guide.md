# Deployment Modes
- dev: test lokaal
- staging: preview voor team
- production: live exports

import React, { useEffect, useState } from 'react';

export default function TenantBanner() {
  const [tenant, setTenant] = useState(null);

  useEffect(() => {
    fetch("/tenants/")
      .then(res => res.json())
      .then(data => setTenant(data[0]));
  }, []);

  if (!tenant) return null;

  return (
    <div className="p-2 text-white text-center" style={{ backgroundColor: tenant.theme_color }}>
      Ingelogd als: {tenant.name}
    </div>
  );
}
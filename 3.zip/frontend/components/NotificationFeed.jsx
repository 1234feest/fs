import React, { useEffect, useState } from 'react';

export default function NotificationFeed() {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    fetch("/notifications/")
      .then(res => res.json())
      .then(setNotifications);
  }, []);

  return (
    <div className="p-4 border rounded shadow mt-6">
      <h2 className="font-semibold mb-2">AI Notificaties</h2>
      <ul>
        {notifications.map((note, idx) => (
          <li key={idx} className="text-orange-700">⚠️ {note}</li>
        ))}
      </ul>
    </div>
  );
}
import React, { useState } from 'react';

export default function PriceSuggestor() {
  const [cost, setCost] = useState("");
  const [suggested, setSuggested] = useState(null);

  const getSuggestion = async () => {
    const res = await fetch("/pricing/suggest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cost_price: parseFloat(cost) })
    });
    const data = await res.json();
    setSuggested(data.suggested_price);
  };

  return (
    <div className="p-4 border shadow rounded mt-6">
      <h2 className="font-semibold mb-2">AI Prijs Suggestie</h2>
      <input
        type="number"
        placeholder="Inkoopprijs"
        value={cost}
        onChange={e => setCost(e.target.value)}
        className="border px-2 py-1 mr-2"
      />
      <button onClick={getSuggestion} className="bg-blue-600 text-white px-4 py-1 rounded">Bereken</button>
      {suggested && <p className="mt-2">AI Suggestie: € {suggested}</p>}
    </div>
  );
}
// Batch 63: Voorraad overzicht

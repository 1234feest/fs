import React, { useState } from 'react';

export default function FeedRulePreview() {
  const [result, setResult] = useState(null);

  const testRule = async () => {
    const res = await fetch("/rules/check", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        product: {price: 15, stock: 3},
        rules: [{type: "price_above", value: 10}, {type: "stock_below", value: 5}]
      })
    });
    const data = await res.json();
    setResult(data.eligible);
  };

  return (
    <div className="p-4 border rounded mt-6">
      <h2 className="font-semibold">Feed Rule Preview</h2>
      <button onClick={testRule} className="bg-indigo-600 text-white px-4 py-1 rounded">Test regels</button>
      {result !== null && <p className="mt-2">Toon in feed: {result ? "✅ Ja" : "❌ Nee"}</p>}
    </div>
  );
}
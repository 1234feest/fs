import React, { useEffect, useState } from 'react';

export default function StatusCard() {
  const [status, setStatus] = useState(null);

  useEffect(() => {
    fetch("/status/")
      .then(res => res.json())
      .then(setStatus);
  }, []);

  if (!status) return <div>Loading status...</div>;

  return (
    <div className="p-4 rounded border shadow">
      <h2>Status</h2>
      <p><strong>Uptime:</strong> {status.uptime}</p>
      <p><strong>Jobs actief:</strong> {status.jobs_active ? "Ja" : "Nee"}</p>
      <p><strong>Versie:</strong> {status.version}</p>
    </div>
  );
}
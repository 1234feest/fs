import React, { useEffect, useState } from 'react';

export default function AnomalyAlerts() {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    fetch("/logs/anomalies")
      .then(res => res.json())
      .then(setAlerts);
  }, []);

  if (!alerts.length) return null;

  return (
    <div className="bg-red-100 border border-red-400 text-red-800 p-4 mt-4 rounded">
      <h2 className="font-bold">🚨 Anomalieën Gedetecteerd</h2>
      <ul className="mt-2 list-disc pl-5">
        {alerts.map((a, i) => <li key={i}>{a}</li>)}
      </ul>
    </div>
  );
}
import React, { useEffect, useState } from 'react';

export default function LogViewer() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    fetch("/logs/")
      .then(res => res.json())
      .then(setLogs);
  }, []);

  return (
    <div className="p-4 rounded border shadow mt-4">
      <h2>Logs</h2>
      <ul>
        {logs.map((log, i) => (
          <li key={i}>
            <strong>{log.event}</strong>: {log.status}
          </li>
        ))}
      </ul>
    </div>
  );
}
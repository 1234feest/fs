import React, { useState } from 'react';

export default function StockAlertChecker() {
  const [stock, setStock] = useState("");
  const [alert, setAlert] = useState(null);

  const checkAlert = async () => {
    const res = await fetch("/alerts/stock", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ stock: parseInt(stock) })
    });
    const data = await res.json();
    setAlert(data.alert);
  };

  return (
    <div className="p-4 border rounded shadow mt-6">
      <h2 className="font-semibold mb-2">AI Voorraad Alert</h2>
      <input
        type="number"
        placeholder="Aantal op voorraad"
        value={stock}
        onChange={e => setStock(e.target.value)}
        className="border px-2 py-1 mr-2"
      />
      <button onClick={checkAlert} className="bg-red-600 text-white px-4 py-1 rounded">Check</button>
      {alert && <p className="mt-2 text-red-700">{alert}</p>}
    </div>
  );
}
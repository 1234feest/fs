// Batch 75: Statusbar met feedback

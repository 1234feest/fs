import React from 'react';

export default function OnboardingPage() {
  return (
    <div className="max-w-md mx-auto mt-10 p-6 shadow rounded border">
      <h1 className="text-xl font-semibold mb-4">Welkom bij FeedSync</h1>
      <p className="mb-2">Stap 1: Vul je bedrijfsnaam in</p>
      <input type="text" className="border px-2 py-1 w-full mb-4" placeholder="Bedrijfsnaam" />
      <p className="mb-2">Stap 2: Kies een hoofdkleur</p>
      <input type="color" className="mb-4" />
      <button className="bg-teal-600 text-white px-4 py-2 rounded">Start</button>
    </div>
  );
}
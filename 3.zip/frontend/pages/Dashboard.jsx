import React from 'react';
import StatusCard from '../components/StatusCard';
import LogViewer from '../components/LogViewer';

export default function DashboardPage() {
  return (
    <div className="container mx-auto mt-6">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <StatusCard />
      <LogViewer />
    </div>
  );
}
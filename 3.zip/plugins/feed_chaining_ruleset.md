# Feed Chaining Ruleset
- If: export to BOL succeeds → then export to Google
- Max loops: 3

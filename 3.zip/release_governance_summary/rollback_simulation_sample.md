# Rollback Simulation
→ Regel 'kortingregel 10%' uitgeschakeld
→ Verwachte impact: 14% minder records met kortingsvermelding

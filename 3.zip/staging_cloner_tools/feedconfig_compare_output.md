# Feedconfig Compare Output
- Regel 3 aangepast: prijsberekening gewijzigd
- Mappingregel 7 verwijderd
- Exportstructuur ongewijzigd

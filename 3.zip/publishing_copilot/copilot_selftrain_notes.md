# Copilot Selftraining
FeedSync leert van de prestaties van voorgestelde mappings:
- Hergebruik succesvolle varianten
- Pas logica aan bij lage matchscores

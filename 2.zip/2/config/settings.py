from pydantic import BaseSettings
class Settings(BaseSettings):
    bol_client_id: str
    bol_client_secret: str
    ls_api_key: str
    postgres_password: str
    redis_url: str
    class Config:
        env_file = '.env'

# Workflow Chaining Voorbeeld
Feed A (import) → Mapping B (prijsvalidatie) → Export C (Bol)

# Copilot Trainingsfeedback
Beoordeel gegenereerde mappingregels met: 👍 / 👎 / 🔁 herschrijven.

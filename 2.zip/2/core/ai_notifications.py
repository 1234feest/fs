NOTIFICATIONS = []

def detect_behavioral_event(event):
    if "return" in event.lower() or "cancel" in event.lower():
        msg = f"Waarschuwing: opvallende gebeurtenis gedetecteerd: '{event}'"
        NOTIFICATIONS.append(msg)
        return msg
    return None

def get_notifications():
    return NOTIFICATIONS
"""
Explainable Root-Cause Finder
Batch 3124
Legt uit waar errors vandaan komen.
"""
def find_root_cause(error_log):
    # TODO: implement
    return {}

"""
Incident Explainability
Batch 3133
Genereert uitleg bij incidenten.
"""
def explain_incident(incident_id):
    # TODO: implement
    return "incident explanation"

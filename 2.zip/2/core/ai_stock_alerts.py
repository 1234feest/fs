def check_stock_alert(product):
    threshold = 5
    if product.get("stock", 0) < threshold:
        return f"Voorraad laag: nog slechts {product['stock']} op voorraad"
    return None
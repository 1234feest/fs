
import logging

# Simuleer verwerking Stripe webhook
def handle_stripe_webhook(payload: bytes, sig_header: str):
    logging.info("Webhook ontvangen van Stripe.")
    # Hier zou validatie komen met stripe.Webhook.construct_event()
    # payload decoded met json.loads(payload.decode())
    if b"invoice.paid" in payload:
        return "Payment success verwerkt"
    elif b"invoice.payment_failed" in payload:
        return "Betaling mislukt verwerkt"
    else:
        return "Webhook ontvangen maar geen actie ondernomen"

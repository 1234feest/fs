"""
Discount Manager
Batch 3688
Beheer promoties en kortingen.
"""
def apply_discount(user, discount_code):
    # TODO: implement
    return "discount_applied"

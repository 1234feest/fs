"""
Renewal Notifier
Batch 3687
Stuur notificaties over abonnement verlenging.
"""
def notify_renewal(user):
    # TODO: implement
    return "notified"

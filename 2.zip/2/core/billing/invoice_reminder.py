"""
Invoice Reminder Service
Batch 3692
Stuur betalingsherinneringen.
"""
def send_invoice_reminder(user):
    # TODO: implement
    return "reminder_sent"

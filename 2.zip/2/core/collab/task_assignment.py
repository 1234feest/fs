"""
Task Assignment Engine
Batch 3647
Wijs taken toe aan gebruikers/teams.
"""
def assign_task(task_id, user_id):
    # TODO: implement
    return "assigned"

"""
Build Monitor
Batch 3924
Monitor build status en fouten.
"""
def monitor_build(build_id):
    # TODO: implement
    return "build_ok"

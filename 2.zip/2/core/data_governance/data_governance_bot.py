"""
Data Governance Bot
Batch 3978
AI assistent voor data governance vragen.
"""
def ask_governance_bot(question):
    # TODO: implement
    return "answer"

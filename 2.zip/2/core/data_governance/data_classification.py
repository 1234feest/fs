"""
Data Classification Engine
Batch 3970
Classificeert data op gevoeligheid en type.
"""
def classify_data(data):
    # TODO: implement
    return "classified"

class ErrorRegistry:
    errors = []

    @classmethod
    def log_error(cls, code, message):
        cls.errors.append({"code": code, "message": message})

    @classmethod
    def get_errors(cls):
        return cls.errors
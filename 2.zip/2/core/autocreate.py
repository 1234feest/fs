
from core.models import Tenant, User
from core.database import SessionLocal
import logging

def auto_create_tenant_and_user(email: str):
    db = SessionLocal()
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        return {"status": "exists", "user_id": existing.id}

    # Maak nieuwe tenant
    tenant = Tenant(name=email.split("@")[0])
    db.add(tenant)
    db.flush()

    # Maak nieuwe gebruiker
    user = User(email=email, hashed_password="changeme", tenant_id=tenant.id, role="admin")
    db.add(user)
    db.commit()

    logging.info(f"Tenant en user aangemaakt voor {email}")
    return {"status": "created", "user_id": user.id, "tenant_id": tenant.id}

"""
Backup Validation Service
Batch 3785
Valideert back-ups en restore processen.
"""
def validate_backup(backup_id):
    # TODO: implement
    return True

"""
Backup Scheduler
Batch 3795
Plant backups en restores.
"""
def schedule_backup(schedule):
    # TODO: implement
    return "scheduled"

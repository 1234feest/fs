"""
Privacy Request Manager
Batch 3173
Beheer privacyverzoeken (AVG e.d.).
"""
def handle_privacy_request(request):
    # TODO: implement
    return "handled"

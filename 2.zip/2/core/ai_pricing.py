def suggest_price(product):
    base_price = product.get("cost_price", 0)
    if base_price <= 0:
        return None
    return round(base_price * 1.25, 2)  # Simpele marge van 25%
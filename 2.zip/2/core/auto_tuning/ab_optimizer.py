"""
Regelsuggestie A/B/C Optimizer
Batch 3002
Implementeer A/B/C tests over feedregels en kies beste variant.
"""
class ABCRuleOptimizer:
    def __init__(self):
        pass  # TODO
    def run_experiment(self, rule_set):
        """
        Run A/B/C experiment op rule_set
        """
        pass  # TODO

"""
Feedbenchmarking
Batch 3013
Meet feedperformance onder verschillende omstandigheden.
"""
def benchmark_feeds(feed_configs):
    # TODO: benchmarking
    pass

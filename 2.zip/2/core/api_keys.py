
import secrets
from datetime import datetime
from pydantic import BaseModel

# In-memory opslag voor voorbeeld
API_KEYS = {}

class APIKey(BaseModel):
    key: str
    user_id: str
    created_at: datetime

def generate_api_key(user_id: str) -> APIKey:
    key = secrets.token_hex(16)
    api_key = APIKey(key=key, user_id=user_id, created_at=datetime.utcnow())
    API_KEYS[key] = api_key
    return api_key

def validate_api_key(key: str) -> bool:
    return key in API_KEYS

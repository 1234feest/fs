
import threading
import time
import random
import logging
from feeds.engine import generate_feed

class TenantAgent(threading.Thread):
    def __init__(self, tenant_id, config, interval=30):
        super().__init__()
        self.tenant_id = tenant_id
        self.config = config
        self.interval = interval
        self.running = True

    def run(self):
        while self.running:
            logging.info(f"[Agent:{self.tenant_id}] Start sync cycle")
            generate_feed(self.tenant_id, self.config)
            time.sleep(self.interval)

    def stop(self):
        self.running = False

AGENTS = {}

def start_agent(tenant_id, config, interval=30):
    if tenant_id in AGENTS:
        return f"Agent {tenant_id} already running"
    agent = TenantAgent(tenant_id, config, interval)
    AGENTS[tenant_id] = agent
    agent.start()
    return f"Agent {tenant_id} started"

def stop_agent(tenant_id):
    agent = AGENTS.get(tenant_id)
    if agent:
        agent.stop()
        agent.join()
        del AGENTS[tenant_id]
        return f"Agent {tenant_id} stopped"
    return f"No agent found for {tenant_id}"

"""
Energy Usage Logger
Batch 3526
Logt energieverbruik van feeds/processen.
"""
def log_energy_usage(process, amount):
    # TODO: implement
    return "energy_logged"

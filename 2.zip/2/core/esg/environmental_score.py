"""
Environmental Score Engine
Batch 3536
Berekent duurzaamheids-/milieuscore.
"""
def compute_environmental_score(data):
    # TODO: implement
    return 0

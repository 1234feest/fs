"""
Partner Green Index Calculator
Batch 3530
Berekent 'groenheidsscore' van partners.
"""
def calculate_green_index(partner):
    # TODO: implement
    return 0

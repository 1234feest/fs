"""
ESG Compliance Checker
Batch 3527
Checkt of processen voldoen aan ESG-standaarden.
"""
def check_compliance(process):
    # TODO: implement
    return True

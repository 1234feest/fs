"""
Environmental Policy Checker
Batch 3532
Controleert milieubeleid/maatregelen bij klanten/partners.
"""
def check_environmental_policy(entity):
    # TODO: implement
    return True

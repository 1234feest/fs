"""
Green Partner Badge Engine
Batch 3524
Verstrekt badges aan groene partners.
"""
def issue_badge(partner):
    # TODO: implement
    return "badge_issued"

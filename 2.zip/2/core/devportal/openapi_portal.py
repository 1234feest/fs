"""
Open API Dev Portal & SDK's
Batch 3183
Portaal voor API's, SDK download en docs.
"""
def get_sdk(language):
    # TODO: implement
    return "sdk_url"

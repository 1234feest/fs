ANOMALIES = []

def scan_logs(logs):
    errors = [log for log in logs if log.get("status") == "error"]
    if len(errors) > 3:
        alert = f"{len(errors)} fouten gedetecteerd in korte tijd"
        ANOMALIES.append(alert)
        return alert
    return None

def get_anomalies():
    return ANOMALIES
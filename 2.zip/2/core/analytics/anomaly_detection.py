"""
Anomaly Detection Engine
Batch 3618
Detecteer afwijkingen in data/gedrag.
"""
def detect_anomalies(data):
    # TODO: implement
    return []

"""
Dashboard Customizer
Batch 4019
Pas dashboards aan per user/rol.
"""
def customize_dashboard(user, config):
    # TODO: implement
    return "customized"

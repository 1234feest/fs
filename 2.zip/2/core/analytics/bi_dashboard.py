"""
Business Intelligence Dashboard
Batch 3602
Dashboard met KPI's, rapportages, visualisaties.
"""
from fastapi import APIRouter
router = APIRouter()
@router.get("/dashboard/bi_dashboard")
def bi_dashboard():
    """
    Toon BI dashboard.
    """
    return {"kpis": [], "reports": []}

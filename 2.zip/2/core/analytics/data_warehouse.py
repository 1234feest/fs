"""
Data Warehouse Connector
Batch 3601
Koppel data pipelines naar warehouse/platform.
"""
def connect_data_warehouse(config):
    # TODO: implement
    return "connected"

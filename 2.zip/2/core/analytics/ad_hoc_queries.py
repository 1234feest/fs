"""
Ad Hoc Query Engine
Batch 3608
Maakt flexibele queries mogelijk.
"""
def run_query(sql):
    # TODO: implement
    return []

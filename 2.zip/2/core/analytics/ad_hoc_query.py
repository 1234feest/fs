"""
Ad Hoc Query Engine
Batch 4008
Maakt flexibele queries mogelijk.
"""
def run_query(query):
    # TODO: implement
    return "query_run"

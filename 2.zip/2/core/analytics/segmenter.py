"""
Customer Segmenter
Batch 3612
Segmenteer gebruikers op basis van gedrag.
"""
def segment_customers(data):
    # TODO: implement
    return []

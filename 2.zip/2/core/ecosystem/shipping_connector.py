"""
Shipping Connector Integration
Batch 3481
Plug-in voor externe shipping carriers/portals.
"""
def connect_shipping(carrier, data):
    # TODO: implement
    return "connected"

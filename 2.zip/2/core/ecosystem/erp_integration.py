"""
ERP System Integration
Batch 3487
ERP integratieplug-in (import/export).
"""
def connect_erp(system, data):
    # TODO: implement
    return "erp_connected"

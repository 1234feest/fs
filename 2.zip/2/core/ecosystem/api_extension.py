"""
API Extension Loader
Batch 3496
Laad extra API’s/features van partners.
"""
def load_api_extension(api):
    # TODO: implement
    return "api_loaded"

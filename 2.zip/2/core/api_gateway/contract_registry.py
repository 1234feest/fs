"""
API Contract Registry
Batch 3331
Beheer contracten per API/partner.
"""
def register_contract(api, partner, terms):
    # TODO: implement
    return "contract_registered"

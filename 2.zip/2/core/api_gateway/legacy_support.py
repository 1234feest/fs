"""
Legacy API Support Layer
Batch 3334
Beheer oudere API endpoints/compatibility.
"""
def enable_legacy_support(api):
    # TODO: implement
    return "legacy_enabled"

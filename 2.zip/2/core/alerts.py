
import logging

def send_slack_alert(message: str):
    logging.warning(f"[ALERT] {message}")
    # Hier zou een echte Slack webhook call komen

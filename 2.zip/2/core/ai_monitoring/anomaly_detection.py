"""
Model Anomaly Detection
Batch 3766
Detecteert afwijkingen in output.
"""
def detect_anomalies(model_output):
    # TODO: implement
    return []

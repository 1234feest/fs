"""
Data Drift Detector
Batch 3774
Detecteert veranderingen in inputdata.
"""
def detect_data_drift(data):
    # TODO: implement
    return False

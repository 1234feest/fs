
# Abstractie over marketplace/exportkanalen
from marketplaces.amazon import push_to_amazon
from marketplaces.kaufland import push_to_kaufland

def push_product_to_channel(product: dict, channel: str):
    if channel == "amazon":
        return push_to_amazon(product)
    elif channel == "kaufland":
        return push_to_kaufland(product)
    elif channel == "local_export":
        return {"status": "success", "channel": "local"}
    else:
        return {"status": "error", "channel": channel, "reason": "unsupported"}

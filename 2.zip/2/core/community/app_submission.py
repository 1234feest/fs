"""
App Submission Workflow
Batch 3590
Stroomlijn indiening van apps/plugins/templates.
"""
def submit_app(user, app_data):
    # TODO: implement
    return "submitted"

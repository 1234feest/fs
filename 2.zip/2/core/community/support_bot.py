"""
Community Support Bot
Batch 3592
AI/FAQ/helpdesk bot voor partners, users.
"""
def support_question(user, question):
    # TODO: implement
    return "response"

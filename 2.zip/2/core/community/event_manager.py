"""
Community Event Manager
Batch 3596
Organiseer events, webinars, meetups.
"""
def create_event(event):
    # TODO: implement
    return "event_created"

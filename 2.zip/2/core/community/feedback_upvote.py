"""
Feedback/Upvote Module
Batch 3586
Laat community feedback en upvotes achterlaten.
"""
def upvote_feedback(user, feedback_id):
    # TODO: implement
    return "upvoted"

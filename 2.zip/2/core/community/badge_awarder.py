"""
Community Badge Awarder
Batch 3585
Vergeef badges aan actieve gebruikers/partners.
"""
def award_badge(user, badge):
    # TODO: implement
    return "awarded"

"""
App Review Engine
Batch 3584
Laat users/partners apps en plugins reviewen.
"""
def submit_app_review(app, user, review):
    # TODO: implement
    return "reviewed"

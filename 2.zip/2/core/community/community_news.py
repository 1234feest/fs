"""
Community Newsfeed Engine
Batch 3597
Publiceer nieuws, updates, releases.
"""
def post_news(article):
    # TODO: implement
    return "news_posted"

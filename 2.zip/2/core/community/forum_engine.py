"""
Community Forum Engine
Batch 3581
Basis voor forum, discussies, Q&A.
"""
def post_forum_message(user, message, topic):
    # TODO: implement
    return "posted"

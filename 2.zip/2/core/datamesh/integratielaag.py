"""
Universele Integratielaag voor marketplaces, PIM, ERP
Batch 3101
Basis voor plug-in van diverse externe systemen.
"""
def connect_external(source_type, credentials):
    # TODO: implement
    pass

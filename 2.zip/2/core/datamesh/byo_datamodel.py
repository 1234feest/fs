"""
Bring Your Own Data Model
Batch 3104
Custom mapping/entiteiten ondersteund.
"""
def map_custom_entity(entity):
    # TODO: implement
    pass

"""
Event Replay Tool
Batch 3115
Herhaalt/speelt events terug voor test/debug.
"""
def replay_event(event_id):
    # TODO: implement
    pass

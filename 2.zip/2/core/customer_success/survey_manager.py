"""
Customer Survey Manager
Batch 3875
Beheer klanttevredenheidsonderzoeken.
"""
def manage_survey(survey):
    # TODO: implement
    return "managed"

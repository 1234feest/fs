"""
Support Ticket System
Batch 3862
Beheer support tickets en opvolging.
"""
def create_ticket(user, issue):
    # TODO: implement
    return "ticket_created"

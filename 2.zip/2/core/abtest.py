
import random

# In-memory simulatie van A/B toewijzingen
ASSIGNMENTS = {}

def assign_user_to_group(user_id: str, experiment: str) -> str:
    key = f"{experiment}:{user_id}"
    if key not in ASSIGNMENTS:
        ASSIGNMENTS[key] = random.choice(["A", "B"])
    return ASSIGNMENTS[key]

def get_user_group(user_id: str, experiment: str) -> str:
    return ASSIGNMENTS.get(f"{experiment}:{user_id}", "unassigned")

"""
Suggestie Autorisatie Module
Batch 3026
Alleen senior users mogen bepaalde regels publiceren.
"""
def check_authorization(user, action):
    # TODO: check role/permissions
    return user == "senior"

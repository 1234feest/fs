"""
Decision Override Logging
Batch 3036
Logt als iemand een AI-voorstel overschrijft.
"""
def log_override(user, suggestion, new_value):
    # TODO: implement
    pass

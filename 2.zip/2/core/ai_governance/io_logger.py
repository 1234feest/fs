"""
Decision Input-Output Logger
Batch 3022
Slaat alle relevante input/output per AI-call op.
"""
def log_io(input_data, output_data):
    # TODO: implement
    pass

"""
AI Ethiek Scanner (PII/AVG)
Batch 3027
Detecteert gevoelige data (naam, geslacht, locatie).
"""
def scan_for_ethics(data):
    # TODO: flag mogelijke PII
    pass

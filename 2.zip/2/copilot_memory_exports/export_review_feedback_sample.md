# Export Review Feedback (sample)
- Titel mist in 3 producten
- Prijsregel werkte correct
- Suggestie: voeg GTIN toe voor Google

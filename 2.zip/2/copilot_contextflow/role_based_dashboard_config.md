# Role-Based Dashboards
- Admin: SLA, errors, releases
- Editor: mappings, preview, Copilot
- Viewer: logs, status, feedhistory

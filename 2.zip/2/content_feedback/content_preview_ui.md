# Content Preview UI
Visualiseer hoe jouw mappingoutput eruitziet op:
- Bol.com
- Google Shopping
- Amazon
